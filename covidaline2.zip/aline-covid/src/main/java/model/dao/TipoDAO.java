package model.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import model.vo.TipoVO;

public class TipoDAO {

	public ArrayList<TipoVO> listarTipos() {
		String query = "SELECT ID, DESCRICAO FROM tipo_usuario";
		Connection conn = Conexao.getConnection();
		Statement stmt = Conexao.getStatement(conn);
		ResultSet resultado = null;
		ArrayList<TipoVO> listaTipos = new ArrayList();

		try {
			resultado = stmt.executeQuery(query);
			while(resultado.next()) {
				TipoVO tipo = new TipoVO();
				tipo.setId(Integer.parseInt(resultado.getString("ID")));
				tipo.setDescricao(resultado.getString("DESCRICAO"));
				listaTipos.add(tipo);
			}
		} catch(SQLException e) {
			System.out.println("Erro ao obter lista de tipos de usuários!");
			System.out.println("Erro: " + e.getMessage());
		} finally {
			Conexao.closeResultSet(resultado);
			Conexao.closeStatement(stmt);
			Conexao.closeConnection(conn);
		}
		return listaTipos;
	}

}