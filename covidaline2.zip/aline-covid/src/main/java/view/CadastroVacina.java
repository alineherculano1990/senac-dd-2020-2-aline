package view;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.text.ParseException;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.text.MaskFormatter;

import controller.VacinaController;
import model.dao.EstagioDAO;
import model.dao.TipoDAO;
import model.vo.EstagioVO;
import model.vo.PesquisadorVO;
import model.vo.PessoaVO;
import model.vo.TipoVO;
import model.vo.VacinaVO;
import utils.Formatadores;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JFormattedTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class CadastroVacina extends JFrame {

	private JPanel contentPane;
	private JTextField txtPaisDeOrigem;
	private JTextField txtPesquisador;

	
	public ArrayList<EstagioVO> carregarEstagiosDeVacinacao() {
		ArrayList<EstagioVO> listaEstagios = new ArrayList();
		EstagioDAO tipoDAO = new EstagioDAO();
		listaEstagios = tipoDAO.listarEstagios();
		return listaEstagios;
	}

	
	public void mascara(String msk, JFormattedTextField txt) {
		try {
			MaskFormatter mask = new MaskFormatter(msk);
			mask.install(txt);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			JOptionPane.showMessageDialog(null, "Erro ao formatar campo", "Erro de Formatação", JOptionPane.ERROR);
		}
	}

	/**
	 * aplicação.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CadastroVacinas frame = new CadastroVacinas();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Criar frame.
	 */
	public CadastroVacinas() {
		setTitle("Cadastro de Vacinas");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblPaisDeOrigem = new JLabel("Pa\u00EDs de Origem:");
		lblPaisDeOrigem.setBounds(10, 11, 146, 14);
		contentPane.add(lblPaisDeOrigem);

		txtPaisDeOrigem = new JTextField();
		txtPaisDeOrigem.setBounds(121, 8, 303, 20);
		contentPane.add(txtPaisDeOrigem);
		txtPaisDeOrigem.setColumns(10);

		JLabel lblestagio = new JLabel("Est\u00E1gio da Pesquisa:");
		lblestagio.setBounds(10, 50, 146, 14);
		contentPane.add(lblestagio);

		JComboBox cbEstagio = new JComboBox();
		cbEstagio.setBounds(10, 66, 414, 20);
		contentPane.add(cbEstagio);
		ArrayList<EstagioVO> estagiosDeVacinacao = this.carregarEstagiosDeVacinacao();
		for(int i = 0; i < estagiosDeVacinacao.size(); i++) {
			cbEstagio.addItem(""+estagiosDeVacinacao.get(i).getId() + " - "+estagiosDeVacinacao.get(i).getDescricao());
		}

		JLabel lblDataInicio = new JLabel("Data de In\u00EDcio:");
		lblDataInicio.setBounds(10, 97, 192, 14);
		contentPane.add(lblDataInicio);

		JFormattedTextField txtDataInicio = new JFormattedTextField();
		txtDataInicio.setBounds(10, 111, 192, 20);
		contentPane.add(txtDataInicio);
		this.mascara("##/##/####", txtDataInicio);

		JLabel lblPesquisador = new JLabel("Pesquisador Respons\u00E1vel:");
		lblPesquisador.setBounds(212, 97, 212, 14);
		contentPane.add(lblPesquisador);

		txtPesquisador = new JTextField();
		txtPesquisador.setBounds(204, 111, 220, 20);
		contentPane.add(txtPesquisador);
		txtPesquisador.setColumns(10);

		JButton btnSalvar = new JButton("Cadastrar Vacina");
		btnSalvar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Formatadores formatador = new Formatadores();
				String paisDeOrigem = txtPaisDeOrigem.getText();
				int estagio =  formatador.retornarIndice(cbEstagio.getSelectedItem().toString());
				String data = txtDataInicio.getText();
				String pesquisador = txtPesquisador.getText();

				VacinaVO vacina = new VacinaVO();
				PesquisadorVO pessoa = new PesquisadorVO();
				pessoa.setNome(pesquisador);

				vacina.setPaisDeOrigem(paisDeOrigem);
				vacina.setEstagioDaPesquisa(estagio);
				vacina.setDataInicioDaPesquisa(data);
				vacina.setPesquisador(pessoa);

				VacinaController vacinaController = new VacinaController();
				vacinaController.cadastrarVacina(vacina);
			}
		});
		btnSalvar.setBounds(10, 142, 192, 23);
		contentPane.add(btnSalvar);
	}
}
