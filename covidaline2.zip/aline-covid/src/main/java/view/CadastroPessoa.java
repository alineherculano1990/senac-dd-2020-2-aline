package view;


import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.ParseException;
import java.util.ArrayList;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.text.MaskFormatter;

import controller.UsuarioController;
import model.dao.TipoDAO;
import model.vo.EnderecoVO;
import model.vo.PesquisadorVO;
import model.vo.TipoVO;
import utils.Formatadores;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.ButtonGroup;
import javax.swing.JComboBox;
import javax.swing.JRadioButton;
import javax.swing.JButton;
import javax.swing.JFormattedTextField;

public class CadastroPessoa extends JFrame {

	private JPanel contentPane;
	private JTextField txtRua;
	private JTextField txtNumero;
	private JTextField txtNome;

	
	public ArrayList<TipoVO> carregarTiposDeUsuarios() {
		ArrayList<TipoVO> listaTipos = new ArrayList();
		TipoDAO tipoDAO = new TipoDAO();
		listaTipos = tipoDAO.listarTipos();
		return listaTipos;
	}

	
	public void mascara(String msk, JFormattedTextField txt) {
		try {
			MaskFormatter mask = new MaskFormatter(msk);
			mask.install(txt);
		} catch (ParseException e) {
			
			JOptionPane.showMessageDialog(null, "Erro ao formatar campo", "Erro de Formatação", JOptionPane.ERROR);
		}
	}

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CadastroPessoas frame = new CadastroPessoas();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public CadastroPessoas() {
		setTitle("Cadastro de Pessoas");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 360);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblNomeCompleto = new JLabel("Nome Completo");
		lblNomeCompleto.setBounds(10, 11, 147, 14);
		contentPane.add(lblNomeCompleto);

		JLabel lblDtNascimento = new JLabel("Nascimento");
		lblDtNascimento.setBounds(10, 60, 109, 14);
		contentPane.add(lblDtNascimento);

		JLabel lblCPF = new JLabel("CPF");
		lblCPF.setBounds(202, 60, 46, 14);
		contentPane.add(lblCPF);

		JLabel lblTipo = new JLabel("Tipo");
		lblTipo.setBounds(10, 170, 46, 14);
		contentPane.add(lblTipo);

		JComboBox cbTipo = new JComboBox();
		cbTipo.setBounds(10, 189, 414, 20);
		contentPane.add(cbTipo);
		ArrayList<TipoVO> tiposDeUsuarios = this.carregarTiposDeUsuarios();
		for(int i = 0; i < tiposDeUsuarios.size(); i++) {
			cbTipo.addItem(""+tiposDeUsuarios.get(i).getId() + " - "+tiposDeUsuarios.get(i).getDescricao());
		}

		/**
		 * Evento que ocorre com a mudança do select do tipo de usuário
		 */
		cbTipo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int itemSelecionado = cbTipo.getSelectedIndex();
				if(itemSelecionado == 0) {
					txtNumero.setEnabled(true);
					txtRua.setEnabled(true);
				} else {
					txtRua.setText("");
					txtNumero.setText("");
					txtRua.setEnabled(false);
					txtNumero.setEnabled(false);
				}
			}
		});

		JLabel lblEndereco = new JLabel("Endere\u00E7o");
		lblEndereco.setBounds(10, 231, 129, 14);
		contentPane.add(lblEndereco);

		txtRua = new JTextField();
		txtRua.setEnabled(true);
		txtRua.setBounds(40, 256, 150, 20);
		contentPane.add(txtRua);
		txtRua.setColumns(10);

		JLabel lblRua = new JLabel("Rua:");
		lblRua.setBounds(10, 259, 46, 14);
		contentPane.add(lblRua);

		JLabel lblNumero = new JLabel("N\u00B0:");
		lblNumero.setBounds(202, 259, 46, 14);
		contentPane.add(lblNumero);

		txtNumero = new JTextField();
		txtNumero.setEnabled(true);
		txtNumero.setBounds(224, 256, 200, 20);
		contentPane.add(txtNumero);
		txtNumero.setColumns(10);

		txtNome = new JTextField();
		txtNome.setBounds(10, 29, 414, 20);
		contentPane.add(txtNome);
		txtNome.setColumns(10);

		JFormattedTextField txtDataNascimento = new JFormattedTextField();
		txtDataNascimento.setBounds(10, 78, 180, 20);
		contentPane.add(txtDataNascimento);
		this.mascara("##/##/####", txtDataNascimento);

		JFormattedTextField txtCPF = new JFormattedTextField();
		txtCPF.setBounds(202, 78, 222, 20);
		contentPane.add(txtCPF);
		this.mascara("###.###.###-##", txtCPF);

		JLabel lblSexo = new JLabel("Sexo:");
		lblSexo.setBounds(10, 109, 46, 14);
		contentPane.add(lblSexo);

		JComboBox cbSexo = new JComboBox();
		cbSexo.setBounds(10, 126, 414, 20);
		contentPane.add(cbSexo);
		cbSexo.addItem("1 - MASCULINO");
		cbSexo.addItem("2 - FEMININO");

		JButton btnSalvar = new JButton("Salvar");
		btnSalvar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				Formatadores formatador = new Formatadores();
				String nome = txtNome.getText().trim();
				String dataNascimento = txtDataNascimento.getText();
				ArrayList<String> vCpf = new ArrayList();
				vCpf.add(".");
				vCpf.add("-");
				String rCpf = formatador.gerarRegex(vCpf);
				String cpf = formatador.removerCaracteres(txtCPF.getText(), rCpf);
				int sexo = formatador.retornarIndice(cbSexo.getSelectedItem().toString());
				int tipo = formatador.retornarIndice(cbTipo.getSelectedItem().toString());
				String rua = txtRua.getText();
				String numero = txtNumero.getText();


				PesquisadorVO usuario = new PesquisadorVO();
				EnderecoVO endereco = new EnderecoVO();
				endereco.setRua(rua);
				endereco.setNumero(numero);
				usuario.setNome(nome);
				usuario.setDataNascimento(dataNascimento);
				usuario.setCpf(cpf);
				usuario.setSexo(sexo);
				usuario.setTipo(tipo);
				usuario.setEndereco(endereco);

				UsuarioController usuarioController = new UsuarioController();
				usuarioController.cadastrarUsuario(usuario);

			}
		});
		btnSalvar.setBounds(10, 287, 89, 23);
		contentPane.add(btnSalvar);
	}
}