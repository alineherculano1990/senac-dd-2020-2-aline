package model.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import model.vo.EstagioVO;

public class EstagioDAO {

	public ArrayList<EstagioVO> listarEstagios() {
		String query = "SELECT ID, DESCRICAO FROM estagio";
		Connection conn = Conexao.getConnection();
		Statement stmt = Conexao.getStatement(conn);
		ResultSet resultado = null;
		ArrayList<EstagioVO> listaEstagios = new ArrayList();

		try {
			resultado = stmt.executeQuery(query);
			while(resultado.next()) {
				EstagioVO tipo = new EstagioVO();
				tipo.setId(Integer.parseInt(resultado.getString("ID")));
				tipo.setDescricao(resultado.getString("DESCRICAO"));
				listaEstagios.add(tipo);
			}
		} catch(SQLException e) {
			System.out.println("Erro ao obter lista de estágios de vacina!");
			System.out.println("Erro: " + e.getMessage());
		} finally {
			Conexao.closeResultSet(resultado);
			Conexao.closeStatement(stmt);
			Conexao.closeConnection(conn);
		}
		return listaEstagios;
	}

}
