package utils;

public class Constantes {

	public static final String ERROR_TITLE = "Erro insperado!";
	public static final String SUCESSO_TITLE = "Válido";

	public static final String CPF_ERROR = "CPF inválido!";
	public static final String DATA_NASCIMENTO_ERROR = " data de nascimento inválida!";
	public static final String USUARIO_CADASTRO_SUCESSO = "Casdastro feito";
	public static final String USUARIO_CADASTRO_ERROR = "Erro no cadrastro";

	public static final String VACINA_PAIS_ERROR = "Poucos caracteres no país informado";
	public static final String VACINA_PESQUISADOR_ERROR = "Poucos caracterres no Pesquisador informado";
	public static final String VACINA_DATA_ERROR = "Data da vacina inválida";
	public static final String VACINA_CADASTRO_SUCESSO = "Cadastro da vacina válido";
}
