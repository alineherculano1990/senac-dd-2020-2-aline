package controller;

	import model.bo.PessoaBO;
	import model.vo.PesquisadorVO;

	public class ControllerPessoa {

		public void cadastrarUsuario(PesquisadorVO usuario) {
			PessoaBO usuarioBO = new PessoaBO();
			ControllerPessoa pessoaBO;
			pessoaBO.cadastrarUsuario(usuario);
		}

	}