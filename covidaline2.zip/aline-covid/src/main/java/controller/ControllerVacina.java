package controller;



import model.bo.VacinaBO;
import model.vo.VacinaVO;

public class VacinaController {

	public void cadastrarVacina(VacinaVO vacina) {
		VacinaBO vacinaBO = new VacinaBO();
		vacinaBO.cadastrarVacina(vacina);
	}

}