package utils;

import java.util.ArrayList;

public class Formatadores {

	public String gerarRegex(ArrayList<String> caracteres) {
		String regex = "";
		regex += "[";
		for(int i = 0; i < caracteres.size(); i++) {
			regex += caracteres.get(i);
		}
		regex += "]";
		return regex;
	}

	public String removerCaracteres(String texto, String regex) {
		return texto.replaceAll(regex, "");
	}

	public int retornarIndice(String opcao) {
		opcao = opcao.trim();
		String[] lista = new String[2];
		lista = opcao.split("-");
		int indice = Integer.parseInt(lista[0].trim());
		return indice;
	}

	public String formatarDataParaSQL(String data) {
		String[] lista = new String[3];
		lista = data.split("/");
		return lista[2] + "-" + lista[1] + "-" + lista[0];
	}

}
