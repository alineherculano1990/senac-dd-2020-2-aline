import javax.swing.JOptionPane;

import model.dao.UsuarioDAO;
import model.vo.PesquisadorVO;
import utils.Constantes;
import utils.Formatadores;
import utils.Validadores;

public class UsuarioBO {

	public boolean validarUsuario(PesquisadorVO usuario) {
		Validadores validador = new Validadores();

		if(!validador.validarCPF(usuario.getCpf())) {
			JOptionPane.showMessageDialog(null, Constantes.CPF_ERROR, Constantes.ERROR_TITLE, JOptionPane.ERROR_MESSAGE);
			return false;
		}

		if(!validador.validarData(usuario.getDataNascimento())) {
			JOptionPane.showMessageDialog(null, Constantes.DATA_NASCIMENTO_ERROR, Constantes.ERROR_TITLE, JOptionPane.ERROR_MESSAGE);
			return false;
		}

		return true;
	}

	public void cadastrarUsuario(PesquisadorVO usuario) {
		if(this.validarUsuario(usuario)) {
			Formatadores formatador = new Formatadores();
			usuario.setDataNascimento(formatador.formatarDataParaSQL(usuario.getDataNascimento()));
			usuario.setFoiVacinada(false);
			usuario.setReacaoAVacina(6);
			UsuarioDAO usuarioDAO = new UsuarioDAO();
			usuarioDAO.cadastrarUsuario(usuario);
			JOptionPane.showMessageDialog(null, Constantes.USUARIO_CADASTRO_SUCESSO, Constantes.SUCESSO_TITLE, JOptionPane.PLAIN_MESSAGE);
		}
	}

}