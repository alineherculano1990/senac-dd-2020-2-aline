package view;

import java.util.ArrayList;
import model.dao.InstituicaoDAO;
import model.dao.UsuarioDAO;
import model.dao.VacinaDAO;
import model.vo.EnderecoVO;
import model.vo.InstituicaoVO;
import model.vo.PesquisadorVO;
import model.vo.VacinaVO;
import utils.Formatadores;
import utils.Validadores;

public class App {

	public static void main(String[] args) {
		
		/* cadastrando instituição pra testes */
		EnderecoVO endereco = new EnderecoVO();
		endereco.setRua("Rua Constantinopla");
		endereco.setNumero("45");
		endereco.setBairro("Bela Vista");
		endereco.setCidade("São José");
		endereco.setEstado("SC");
		
		InstituicaoVO instituicao = new InstituicaoVO();
		instituicao.setNome("Instituição Vacina Segura");
		instituicao.setCnpj("00000000/00");
		instituicao.setEndereco(endereco);
		
		/* cadastrando vacina pra testes */
		PesquisadorVO pesquisador = new PesquisadorVO();
		pesquisador.setId(2);
		
		VacinaVO vacina = new VacinaVO();
		vacina.setPaisDeOrigem("China");
		vacina.setEstagioDaPesquisa(1);
		vacina.setDataInicioDaPesquisa("2020-08-20");
		vacina.setPesquisador(pesquisador);
		
		/* cadastrando usuário para testes */
		PesquisadorVO usuario = new PesquisadorVO();
		usuario.setNome("Maria Clara Barros");
		usuario.setDataNascimento("1989-01-11");
		usuario.setSexo(1);
     	usuario.setCpf("00367890892");
		usuario.setTipo(1);
		usuario.setFoiVacinada(false);
		usuario.setReacaoAVacina(3);
		EnderecoVO enderecoUsuario = new EnderecoVO();
		enderecoUsuario.setRua("Rua do Usuário");
		enderecoUsuario.setNumero("777748A");
		enderecoUsuario.setBairro("Bairro do Usuário Alterado");
		enderecoUsuario.setCidade("Cidade do Usuário");
		enderecoUsuario.setEstado("Estado do Usuário");
		usuario.setEndereco(enderecoUsuario);
		
		/*Criando as entidades para testes*/
		InstituicaoDAO instituicaoDAO = new InstituicaoDAO();
		UsuarioDAO usuarioDAO = new UsuarioDAO();
		VacinaDAO vacinaDAO = new VacinaDAO();
		
		/* ====== CRUD INSTITUIÇÃO ======*/
		/* cadastra instituição */
		//instituicaoDAO.cadastrarInstituicao(instituicao);
		
		/* altera instituição passando um objeto instituição e o ID dela no banco de dados */
		//instituicaoDAO.alterarInstituicao(instituicao, 1);
		
		/* retorna um objeto instituição passando o ID como parâmetro */
		//instituicaoDAO.encontrarInstituicao(1);
		
		/* retorna um arraylist de instituições com todas as instituições cadastradas no banco */
		//instituicaoDAO.listarInstituicoes();
		
		/* exclui uma instituição passando o ID dela no banco como parâmetro */
		//instituicaoDAO.excluirInstituicao(1);
		
		/* ====== CRUD USUÁRIOS ======*/
		/* cadastra usuário */
		//usuarioDAO.cadastrarUsuario(usuario);
		
		/* exclui um usuário pelo ID */
		//usuarioDAO.excluirUsuario(1);
		
		/* alterar usuário pelo ID */
		//usuarioDAO.alterarUsuario(usuario, 2);
		
		/* encontrar usuário pelo ID */
		//usuarioDAO.encontrarUsuario(2);
		
		/* listar todos os usuários */
		//usuarioDAO.listarUsuarios();
		
		/* ====== CRUD VACINAS ======*/
		/* cadastrar vacina */
		//vacinaDAO.cadastrarVacina(vacina);
		
		/* excluir vacina pelo ID */
		//vacinaDAO.excluirVacina(2);
		
		/* alterar vacina através do ID */
		//vacinaDAO.alterarVacina(vacina, 3);
		
		/* encontrarvacina através do IF */
		//vacinaDAO.encontrarVacina(1);

		/* lista todas as vacinas */
		//vacinaDAO.listarVacinas();

		//vacinaDAO.listarVacinas();	

		/* instancio o formatador */
		Formatadores formatter = new Formatadores();

		/* digamos que eu queira retirar pontos, traços de um CPF */
		/* então eu coloco num arraylist esses caracteres */
		/*
		ArrayList<String> caracteres = new ArrayList();
		caracteres.add(".");
		caracteres.add("-");
		*/

		/* agora eu chamo a função que gera um regex e passo o arraylist como parâmetro */
		//String regex = formatter.gerarRegex(caracteres);

		/* mando retirar isso de um cpf qualquer */
		/*
		String cpf = "589.658.699-89";
		String cpfFormatado = formatter.removerCaracteres(cpf, regex);
		System.out.println(cpfFormatado);
		*/

		/* instancio o validador */
		Validadores validador = new Validadores();

		/*
		String cpf = "05256325689";
		if(validador.validarCPF(cpf)) {
			System.out.println("CPF válido!");
		} else {
			System.out.println("CPF inválido!");
		}
		*/

		/*
		String email = "gui-keanne@hotmail.com";
		if(validador.validarEmail(email)) {
			System.out.println("E-mail válido!");
		} else {
			System.out.println("E-mail inválido!");
		}
		*/

		String data = "20/11/1990";
		if(validador.validarData(data)) {
			System.out.println("Data válida!");
		} else {
			System.out.println("Data inválida!");
		}
	}

}