package model.vo;

public class VoluntarioVO extends PessoaVO {

	public VoluntarioVO() {
		super();
		// TODO Auto-generated constructor stub
	}
	

}
