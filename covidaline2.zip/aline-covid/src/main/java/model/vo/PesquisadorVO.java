package model.vo;

 
public class PesquisadorVO extends PessoaVO {

 

    private InstituicaoVO instituicao;

 

    public PesquisadorVO() {
        super();
        // TODO Auto-generated constructor stub
    }

 

    public InstituicaoVO getInstituicao() {
        return instituicao;
    }

 

    public void setInstituicao(InstituicaoVO instituicao) {
        this.instituicao = instituicao;
    }
    
    
    
}