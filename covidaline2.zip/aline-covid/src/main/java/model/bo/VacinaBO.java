package model.bo;

import javax.swing.JOptionPane;

import model.dao.VacinaDAO;
import model.vo.VacinaVO;
import utils.Constantes;
import utils.Formatadores;
import utils.Validadores;

public class VacinaBO {

	public boolean validarVacina(VacinaVO vacina) {
		Validadores validador = new Validadores();
		String pais = vacina.getPaisDeOrigem().trim();
		String pesquisador = vacina.getPesquisador().getNome().trim();

		if(pais.length() < 3) {
			JOptionPane.showMessageDialog(null, Constantes.VACINA_PAIS_ERROR, Constantes.ERROR_TITLE, JOptionPane.ERROR_MESSAGE);
			return false;
		}

		if(pesquisador.length() < 3) {
			JOptionPane.showMessageDialog(null, Constantes.VACINA_PESQUISADOR_ERROR, Constantes.ERROR_TITLE, JOptionPane.ERROR_MESSAGE);
			return false;
		}

		if(!validador.validarData(vacina.getDataInicioDaPesquisa())) {
			JOptionPane.showMessageDialog(null, Constantes.VACINA_DATA_ERROR, Constantes.ERROR_TITLE, JOptionPane.ERROR_MESSAGE);
			return false;
		}

		return true;
	}

	public void cadastrarVacina(VacinaVO vacina) {
		if(this.validarVacina(vacina)) {
			Formatadores formatador = new Formatadores();
			vacina.setDataInicioDaPesquisa(formatador.formatarDataParaSQL(vacina.getDataInicioDaPesquisa()));
			VacinaDAO vacinaDAO = new VacinaDAO();
			vacinaDAO.cadastrarVacina(vacina);
			JOptionPane.showMessageDialog(null, Constantes.VACINA_CADASTRO_SUCESSO, Constantes.SUCESSO_TITLE, JOptionPane.PLAIN_MESSAGE);
		}
	}

}
